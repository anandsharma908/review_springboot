package com.mongo.model;

import org.springframework.data.mongodb.core.mapping.Field;

public class Review {
	@Field(value = "userId")
	String userId;
	
	@Field(value = "businessId")
	String businessId;

	@Field(value = "businessRating")
	Integer businessRating;
	
	@Field(value = "businessTitle")
	String businessTitle;
	@Field(value = "businessDescription")
	String businessDescription;
	
	@Field(value = "productId")
	String productId;

	//@Field(value = "userId")
	//String userId;
	
	
	@Field(value = "productRating")
	Integer productRating;
    
	
	
	
	
	//@Field(value = "reviewDescription")
	//String reviewDescription;
	
	@Field(value = "productTitle")
	String productTitle;
	
	@Field(value = "productDescription")
	String productDescription;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getBusinessId() {
		return businessId;
	}

	public void setBusinessId(String businessId) {
		this.businessId = businessId;
	}

	public Integer getBusinessRating() {
		return businessRating;
	}

	public void setBusinessRating(Integer businessRating) {
		this.businessRating = businessRating;
	}

	public String getBusinessTitle() {
		return businessTitle;
	}

	public void setBusinessTitle(String businessTitle) {
		this.businessTitle = businessTitle;
	}

	public String getBusinessDescription() {
		return businessDescription;
	}

	public void setBusinessDescription(String businessDescription) {
		this.businessDescription = businessDescription;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public Integer getProductRating() {
		return productRating;
	}

	public void setProductRating(Integer productRating) {
		this.productRating = productRating;
	}

	public String getProductTitle() {
		return productTitle;
	}

	public void setProductTitle(String productTitle) {
		this.productTitle = productTitle;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	@Override
	public String toString() {
		return "Review [userId=" + userId + ", businessId=" + businessId + ", businessRating=" + businessRating
				+ ", businessTitle=" + businessTitle + ", businessDescription=" + businessDescription + ", productId="
				+ productId + ", productRating=" + productRating + ", productTitle=" + productTitle
				+ ", productDescription=" + productDescription + "]";
	}

	
			
}
