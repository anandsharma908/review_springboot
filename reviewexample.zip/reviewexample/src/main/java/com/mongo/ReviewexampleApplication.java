package com.mongo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReviewexampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReviewexampleApplication.class, args);
	}
}
