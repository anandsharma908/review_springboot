package com.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.mongo.model.Review;

@RepositoryRestResource(collectionResourceRel = "review", path = "review")
public interface ReviewRepository extends MongoRepository<Review, String> {

}
