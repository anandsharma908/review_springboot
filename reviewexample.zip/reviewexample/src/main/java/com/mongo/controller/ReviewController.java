package com.mongo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mongo.model.Review;
import com.mongo.revievservice.ReviewService;

@RestController
public class ReviewController {
	@Autowired
	ReviewService service;

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public Review create(@RequestBody Review review) {
		return service.create(review);
	}

	@RequestMapping(value = "/getAll", method = RequestMethod.GET)
	public List<Review> getAll() {
		return service.getAll();
	}

}
