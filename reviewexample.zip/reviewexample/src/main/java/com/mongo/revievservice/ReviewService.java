package com.mongo.revievservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mongo.model.Review;
import com.mongo.repository.ReviewRepository;

@Service
public class ReviewService {
	@Autowired
	ReviewRepository repository;

	public Review create(Review review) {
		return repository.save(review);
	}

	public List<Review> getAll() {
		return repository.findAll();
	}
}
